#ifndef OGLOSZENIA_H
#define OGLOSZENIA_H

#include <QDialog>

namespace Ui {
class Ogloszenia;
}

class Ogloszenia : public QDialog
{
    Q_OBJECT

public:
    explicit Ogloszenia(QWidget *parent = nullptr);
    ~Ogloszenia();

private:
    Ui::Ogloszenia *ui;
};

#endif // OGLOSZENIA_H
